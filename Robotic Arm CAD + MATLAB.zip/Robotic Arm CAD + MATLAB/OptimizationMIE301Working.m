optimizeMechanism()
function drawMechanism(linkX_length, linkY_length, linkZ_length, a, b, h, beta, theta, alpha, gamma)

    % Define coordinates for the ground pivot
    pivotX = 0;
    pivotY = h;

    % Calculate coordinates for the end of link X
    endX_X = pivotX + linkX_length * cosd(beta);
    endY_X = pivotY - linkX_length * sind(beta);

    % Calculate coordinates for the end of link Y
    endX_Y = endX_X + linkY_length * cosd(theta);
    endY_Y = endY_X - linkY_length * sind(theta);

    % Calculate coordinates for the ends of double end effector Z
    endX_Z1 = endX_Y + linkZ_length * cosd(theta + alpha);
    endY_Z1 = endY_Y - linkZ_length * sind(theta + alpha);

    endX_Z2 = endX_Y + linkZ_length * cosd(theta - gamma);
    endY_Z2 = endY_Y - linkZ_length * sind(theta - gamma);

    % Plot the mechanism
    figure;
    hold on;

    % Plot links
    plot([pivotX, endX_X], [pivotY, endY_X], 'LineWidth', 2, 'Marker', 'o');
    plot([endX_X, endX_Y], [endY_X, endY_Y], 'LineWidth', 2, 'Marker', 'o');
    plot([endX_Y, endX_Z1], [endY_Y, endY_Z1], 'LineWidth', 2, 'Marker', 'o');
    plot([endX_Y, endX_Z2], [endY_Y, endY_Z2], 'LineWidth', 2, 'Marker', 'o');

    % Plot ground pivot
    plot(pivotX, pivotY, 'ro', 'MarkerSize', 8);

    % Plot fuselage around the mechanism
    fuselageX = [0, a, a, 0, 0];
    fuselageY = [0, 0, b, b, 0];
    fill(fuselageX, fuselageY, 'c', 'FaceAlpha', 0.3);

    % Set axis limits based on fuselage dimensions
    axis([0, a, 0, b]);

    % Label the plot
    title('Mechanism in Fuselage');
    xlabel('X-axis');
    ylabel('Y-axis');
    grid on;

    % Legend
    legend('Link X', 'Link Y', 'Link Z1', 'Link Z2', 'Ground Pivot', 'Fuselage');

end
function optimizeMechanism()

    % Initial guess
    initialGuess = [25, 14, 12, -20, 110, 50, 130, 15];

    % Lower and upper bounds for the variables
    lb = [5, 5, 5, -180, -180, -180, -180, 2];
    ub = [58.5, 58.5, 25, 180, 180, 180, 180, 48.9];

    % Constraint function
    nonlcon = @constraints;

    % Objective function
    objective = @(x) -calculateFullyExtendedLength(x);

    % Perform optimization
    options = optimoptions('fmincon', 'Display', 'iter', 'MaxFunctionEvaluations', 1000);
    optimizedVariables = fmincon(objective, initialGuess, [], [], [], [], lb, ub, nonlcon, options);

    % Display results
    disp('Optimized Link Lengths and Angles:');
    disp(['Link X Length: ', num2str(optimizedVariables(1))]);
    disp(['Link Y Length: ', num2str(optimizedVariables(2))]);
    disp(['Link Z Length: ', num2str(optimizedVariables(3))]);
    disp(['Beta: ', num2str(optimizedVariables(4))]);
    disp(['Theta: ', num2str(optimizedVariables(5))]);
    disp(['Alpha: ', num2str(optimizedVariables(6))]);
    disp(['Gamma: ', num2str(optimizedVariables(7))]);
    disp(['Ground Position h: ', num2str(optimizedVariables(8))]);

    % Draw the mechanism
    drawMechanism(optimizedVariables(1), optimizedVariables(2), optimizedVariables(3), 48.9, 58.5, optimizedVariables(8), ...
        optimizedVariables(4), optimizedVariables(5), optimizedVariables(6), optimizedVariables(7));

end

function [c, ceq] = constraints(variables)
    % Constraints function: ensure the mechanism fits inside the fuselage

    % Extract variables for clarity
    linkX_length = variables(1);
    linkY_length = variables(2);
    linkZ_length = variables(3);
    beta = variables(4);
    theta = variables(5);
    alpha = variables(6);
    gamma = variables(7);
    groundPosition_h = variables(8);

    % Define fuselage dimensions
    a = 48.9;
    b = 58.5;

    % Calculate coordinates for the mechanism
    pivotX = 0;
    pivotY = groundPosition_h;

    endX_X = pivotX + linkX_length * cosd(beta);
    endY_X = pivotY - linkX_length * sind(beta);

    endX_Y = endX_X + linkY_length * cosd(theta);
    endY_Y = endY_X - linkY_length * sind(theta);

    endX_Z1 = endX_Y + linkZ_length * cosd(theta + alpha);
    endY_Z1 = endY_Y - linkZ_length * sind(theta + alpha);

    endX_Z2 = endX_Y + linkZ_length * cosd(theta - gamma);
    endY_Z2 = endY_Y - linkZ_length * sind(theta - gamma);

    % Constraints
    c = [endX_X - a;     % Check if Link X is inside fuselage along X
        endY_X - b;      % Check if Link X is inside fuselage along Y
        endX_Y - a;      % Check if Link Y is inside fuselage along X
        endY_Y - b;      % Check if Link Y is inside fuselage along Y
        endX_Z1 - a;     % Check if Link Z1 is inside fuselage along X
        endY_Z1 - b;     % Check if Link Z1 is inside fuselage along Y
        endX_Z2 - a;     % Check if Link Z2 is inside fuselage along X
        endY_Z2 - b;     % Check if Link Z2 is inside fuselage along Y
        -min([endX_X, endX_Y, endX_Z1, endX_Z2]);  % Ensure no X coordinate is negative
        -min([endY_X, endY_Y, endY_Z1, endY_Z2]);  % Ensure no Y coordinate is negative
        endY_Z1 - pivotY;  % Ensure the top of Link Z1 stays within the fuselage
        alpha + gamma - 180];  % Ensure alpha and gamma sum to 180

    % Additional constraints to limit angles within reasonable ranges
    angleConstraints = [beta + theta + alpha + gamma - 180;      % Sum of angles <= 180
                        -beta - theta - alpha - gamma + 180;      % Sum of angles >= -180
                        -beta - theta - alpha - gamma + 90];      % Sum of angles >= -90

    c = [c; angleConstraints];

    % No equality constraints
    ceq = [];
end


function fullyExtendedLength = calculateFullyExtendedLength(variables)
    % Calculate the fully extended length of the mechanism
    pivotX = 0;
    pivotY = variables(8);

    endX_X = pivotX + variables(1) * cosd(variables(4));
    endY_X = pivotY - variables(1) * sind(variables(4));

    endX_Y = endX_X + variables(2) * cosd(variables(5));
    endY_Y = endY_X - variables(2) * sind(variables(5));

    endX_Z1 = endX_Y + variables(3) * cosd(variables(5) - variables(7));
    endY_Z1 = endY_Y - variables(3) * sind(variables(5) - variables(7));

    endX_Z2 = endX_Y + variables(3) * cosd(variables(5) + variables(6));
    endY_Z2 = endY_Y - variables(3) * sind(variables(5) + variables(6));

    fullyExtendedLength = sqrt((endX_Z1 - pivotX)^2 + (endY_Z1 - pivotY)^2) + sqrt((endX_Z2 - pivotX)^2 + (endY_Z2 - pivotY)^2);
end